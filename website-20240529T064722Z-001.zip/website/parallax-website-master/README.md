# parallax-website

Using modern HTML + CSS Principles, this onepage application is built without any JQuery or JS to start off
Once all the content is in place, JS & Jquery will be added to create animations and other cool effects. 
This site is mobile/Tablet/Desktop responsive with media queries to adjust content for screen sizing

watch the action live on :
https://dujota.github.io/parallax-website/
